#!/bin/bash

CURRENT_DIR=`pwd`
INSTALL_DIR=/usr/local/readerSrv

#停止父子进程
function kill_pro(){
    PID=`ps -ef | grep "$1"  | grep -v "grep" | awk '{print $2}'`
    [ -n "$PID" ] && kill -- -$PID
}

libevent_install()
{	
	rm /usr/local/lib/libevent*  -rf
	cd lib/ && tar zxvf libevent-2.1.11-stable.tar.gz
	cd libevent-2.1.11-stable && ./configure 
	make && make install 
	
	if [ `grep -c "/usr/local/lib" /etc/ld.so.conf` -eq '0' ]
	then
		echo "/usr/local/lib" >> /etc/ld.so.conf
	fi	
	
	ldconfig
}

readerSrv_install()
{
	if [[ -d "/usr/local/readerSrv" ]]; then
		rm -rf /usr/local/readerSrv
	fi	
	
	cd $CURRENT_DIR
	cp -rf ./readerSrv $INSTALL_DIR
	cp readerSrv.sh $INSTALL_DIR/conf
	cp check_readerSrv.sh $INSTALL_DIR/conf

	ln -sf $INSTALL_DIR/conf/readerSrv.sh  /usr/bin/readerSrv
}

add_config_start_running()
{
	if [ `grep -c "readerSrv.sh" /etc/rc.local` -eq '0' ]
	then
		echo -e "\e[1;34m readerSrv Set to Auto Start\e[0m"
		# add to Start up
		echo $INSTALL_DIR/conf/readerSrv.sh start >> /etc/rc.local
		echo "nohup $INSTALL_DIR/conf/check_readerSrv.sh &" >> /etc/rc.local
		chmod +x $INSTALL_DIR/conf/readerSrv.sh
		chmod +x $INSTALL_DIR/conf/check_readerSrv.sh
		chmod +x /etc/rc.d/rc.local
	fi	
}

start()
{
	echo -e "\e[1;34m readerSrv Start\e[0m"
	$INSTALL_DIR/bin/reader_srv
}

stop()
{
	echo -e "\e[1;34m readerSrv Stop\e[0m"
	kill_pro "/usr/local/readerSrv/bin/reader_srv" || echo ""
}

status()
{
	ps -ef | grep "/usr/local/readerSrv/bin/reader_srv" | grep -v grep  >> /dev/null
	if [ $? -eq 0 ]; then
		echo -e "\e[1;32m active (running)\e[0m"
	else
		echo -e "\e[1;31m inactive (dead)\e[0m"
	fi
}

case "$1" in
install)
	echo -e "\e[1;34m readerSrv Installing...\e[0m"
	libevent_install
	readerSrv_install	
	add_config_start_running
	echo -e "\e[1;34m readerSrv Install Complete\e[0m"
  ;;
start)
	start	
  ;;
stop)
	stop
  ;;
restart)
	stop
	sleep 1
	start	
  ;;
status)
	status
  ;;
*)
  echo $"Usage: $0 {install | start | stop | restart | status}"
  exit 1
esac
