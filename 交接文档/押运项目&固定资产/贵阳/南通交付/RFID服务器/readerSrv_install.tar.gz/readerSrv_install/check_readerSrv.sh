#!/bin/bash

# check seconds 
CHECK_INTERVAL_SECONDS=20
LOG_FILE=/usr/local/readerSrv/log/reader_srv.log 

while true
do
	echo -e "\e[1;32m check readerSrv process\e[0m"

	ps -ef | grep "/bin/reader_srv" | grep -v grep >/dev/null 2>&1
	if [ $? -ne 0 ];then
		echo -e "\e[1;31m readerSrv process exit, restart\e[0m" >> $LOG_FILE
		readerSrv restart
	fi

	sleep $CHECK_INTERVAL_SECONDS
done 
